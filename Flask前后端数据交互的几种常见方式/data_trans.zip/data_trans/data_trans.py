from flask import Flask, jsonify, render_template, request
from flask_wtf import Form
from wtforms import StringField,SubmitField
from wtforms.validators import DataRequired


app = Flask(__name__)
app.config.from_pyfile('config.py')


@app.route('/')
def hello_world():
    return render_template('test.html')

@app.route('/trans')
def trans():
    return render_template('form.html')

@app.route('/trans1', methods=['post'])
def trans1():
    name = request.get_json('name')
    print(name['name'])
    return jsonify(name['name'] + '233333')

class TestForm(Form):
    name = StringField('name', validators=[DataRequired()])
    submit = SubmitField(label='submit')


@app.route('/wtform', methods=['GET','POST'])
def wtform():
    form = TestForm()
    name = form.name.data
    print(name)
    return render_template('wtform.html', form=form, name=name)

@app.route('/xmlhttp', methods=['GET', 'POST'])
def xmlhttp():
    if request.method == 'POST':
        name = request.form['name']
        return 'hello' + name
    return render_template('XMLHttpRequest.html')




if __name__ == '__main__':
    app.run()
